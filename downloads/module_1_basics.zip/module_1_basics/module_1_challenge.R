# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 1 CHALLENGE
# 🏫 THEME: CHILTON BASICS
# ------------------------------------------------------------------------------
# Welcome to Chilton! Headmaster Charleston expects nothing but excellence.

# TASK 1: PACKAGES
# 1a. Load the 'tidyverse' and 'skimr' packages.
# Write your code below:


# TASK 2: OBJECTS & NAMING
# 2a. Create an object for the number of classes Rory takes. Name it 'rory_classes' and assign it the value 6.

# 2b. Create an object for Paris's favorite subject. Name it 'paris_favorite' and assign it the text "Literature".

# 2c. Fix this bad variable name: `1st place` <- "Paris". Name it correctly using snake_case.


# TASK 3: MATH & PEMDAS
# 3a. Calculate the average of Rory's recent test scores: 98, 95, and 99.
# You must use PEMDAS (parentheses) and the division operator (/). Assign it to 'rory_average'.

# 3b. Calculate 5 raised to the power of 3 (^), multiplied by 2 (*).

# 3c. Calculate 100 minus 50, then divide the result by 2.


# TASK 4: LOGIC
# 4a. Ask R if Rory's average (from 3a) is greater than (>) 95.

# 4b. Ask R if Paris's favorite subject (from 2b) is exactly equal to (==) "Math".

# 4c. Ask R if 10 is NOT equal to (!=) 10.

# 4d. Ask R if 50 is less than (<) 100.

# 4e. Ask R if 100 is greater than or equal to (>=) 100.

# 4f. Ask R if 20 is less than or equal to (<=) 15.


# TASK 5: VECTORS
# 5a. Create a vector of Chilton student grades: 92.5, 98.0, 88.5, 95.0.
# Name the vector 'chilton_grades'.

# 5b. Create a vector of student names: "Paris", "Rory", "Louise". Name it 'puff_members'.


# TASK 6: DATA TYPES
# 6a. Check the class() of the 'chilton_grades' vector.

# 6b. Check the class() of the text "Headmaster Charleston".

# 6c. Check the class() of the value TRUE.


# TASK 7: COMMENTS
# 7a. Write a comment below saying: "I will survive Chilton"


# TASK 8: SUMMARIZING DATA
# 8a. We have a CSV file called 'students.csv'. Read it into an object called 'students'.
# Hint: students <- read.csv("students.csv")


# 8b. Use the skim() function from the skimr package to get a summary of the 'students' dataset.


# ------------------------------------------------------------------------------
# 🎉 GREAT JOB! If your code runs without errors, you survive another day at Chilton!
# ------------------------------------------------------------------------------
