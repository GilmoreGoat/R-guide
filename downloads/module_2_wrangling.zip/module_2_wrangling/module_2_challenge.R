# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 2 CHALLENGE
# 🍔 THEME: LUKE'S DINER
# ------------------------------------------------------------------------------
# Luke is overwhelmed and needs you to manage the diner's data.

# Setup: Load tidyverse
library(tidyverse)

# Read the data
menu <- read.csv("menu.csv")
customers <- read.csv("customers.csv")
orders <- read.csv("orders.csv")

# TASK 1: PULL vs SELECT
# 1a. Create a new dataframe called 'menu_items' that only contains the 'item' and 'price' columns from 'menu'.
# Use select().

# 1b. Select all columns EXCEPT 'calories' from 'menu' (use -).

# 1c. Extract just the 'calories' column from 'menu' as a vector. Use pull().


# TASK 2: THE DOLLAR SIGN
# 2a. Extract the 'name' column from the 'customers' dataframe using the $ shortcut.


# TASK 3: FILTER
# 3a. Filter the 'menu' to only show items with a price greater than (>) 5.00.

# 3b. Filter the 'customers' to show everyone who is NOT (!=) a "VIP".

# 3c. Filter the 'menu' to show only the "Burger" item (==).

# 3d. Filter 'menu' for items with calories < 500 AND price <= 6.50.


# TASK 4: ARRANGE
# 4a. Sort the 'menu' by 'calories' from highest to lowest (descending).

# 4b. Sort the 'orders' by 'tips' from lowest to highest (ascending).


# TASK 5: MUTATE
# 5a. Luke is raising prices! Mutate the 'menu' to add a new column 'new_price'
# that is the 'price' + 2.00. Assign this to a new object 'updated_menu'.

# 5b. Mutate 'menu' to add a column 'price_per_calorie' (price / calories).


# TASK 6: INSPECTING
# 6a. Use table() on the 'status' column of the 'customers' dataframe to count the types of customers.

# 6b. Use unique() to find the unique statuses in 'customers'.


# TASK 7: GROUP_BY & SUMMARISE
# 7a. Group the 'customers' dataframe by 'status', and summarise to count the number of people in each status (use n()).

# 7b. Using 'orders', summarise the total tips (sum(tips)) and average tip (mean(tips)).

