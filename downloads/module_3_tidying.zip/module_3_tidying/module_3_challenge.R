# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 3 CHALLENGE
# 🏨 THEME: THE DRAGONFLY INN
# ------------------------------------------------------------------------------
# Sookie's kitchen data is a mess! Let's pivot it.

library(tidyverse)
kitchen <- read.csv("kitchen.csv")
long_data <- read.csv("long_data.csv")
supplies <- read.csv("supplies.csv")

# TASK 1: PIVOT LONGER
# 1a. Use pivot_longer() on 'kitchen' to combine the 'Monday' and 'Tuesday' columns.
# Call the new name column "Day" and the value column "Eggs". Assign to 'kitchen_long'.

# 1b. The 'supplies' data is wide. It has 'Apples', 'Oranges', 'Bananas'.
# Pivot it longer! Names to "Fruit", values to "Count". Assign to 'supplies_long'.


# TASK 2: PIVOT WIDER
# 2a. Use pivot_wider() on 'long_data'.
# Take column names from "Day" and values from "Eggs". Assign to 'kitchen_wide'.

# 2b. Use pivot_wider() on 'supplies_long' (from 1b) to turn it back to wide format.

