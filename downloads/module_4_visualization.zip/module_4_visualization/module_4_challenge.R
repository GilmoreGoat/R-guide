# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 4 CHALLENGE
# 🎨 THEME: FESTIVAL OF LIVING ART
# ------------------------------------------------------------------------------
# Make some art using ggplot2!

library(tidyverse)
art_entries <- read.csv("art_entries.csv")
paint_tubes <- read.csv("paint_tubes.csv")

# TASK 1: HISTOGRAM
# 1a. Start a plot with 'paint_tubes'. Set x-axis to 'volume'. Add a histogram.

# 1b. Try changing the 'bins' argument in geom_histogram to 10.


# TASK 2: BAR PLOT
# 2a. Plot 'art_entries' with x-axis 'painting'. Add a bar plot.

# 2b. Plot 'art_entries' with x-axis 'contestant'.


# TASK 3: BOXPLOT
# 3a. Plot 'art_entries'. Set x to 'painting' and y to 'pose_time'. Add a boxplot.

# 3b. Plot 'paint_tubes'. Set x to 'brand' and y to 'volume'. Add a boxplot.


# TASK 4: SCATTERPLOT
# 4a. Plot 'paint_tubes'. Set x to 'volume' and y to 'volume' (just for demo). Add points.

# 4b. Change the color of the points in 4a to "blue" inside geom_point().


# TASK 5: COLOR vs FILL
# 5a. Plot 'paint_tubes' with x = 'brand' and fill = 'brand'. Add a bar plot.

# 5b. Plot 'paint_tubes' with x = 'volume' and color = 'brand'. Add a scatterplot (geom_point).


# TASK 6: LABELS & THEMES
# 6a. Take your scatterplot from Task 4a, add theme_classic(), a title using labs(), and change x/y labels.


# TASK 7: FACETING
# 7a. Plot 'paint_tubes' with x='volume', add a histogram, and facet_wrap(~ brand).

# 7b. Plot 'art_entries' with x='pose_time', add a histogram, and facet_wrap(~ painting).

