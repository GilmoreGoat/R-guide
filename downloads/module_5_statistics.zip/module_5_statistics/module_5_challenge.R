# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 5 CHALLENGE
# 🎓 THEME: YALE STATISTICS
# ------------------------------------------------------------------------------

library(tidyverse)
stunt_heights <- read.csv("stunt_heights.csv")
yale_students <- read.csv("yale_students.csv")
lizards <- read.csv("lizards.csv")
creams <- read.csv("creams.csv")

# TASK 1: DATA CLEANING
# 1a. Filter 'stunt_heights' to keep height_m < 100. Assign to 'clean_stunts'.

# 1b. Filter 'yale_students' to keep hours_studied >= 0 (no negative study hours!).


# TASK 2: NORMALITY CHECK
# 2a. Run ks.test on clean_stunts$height_m (using y="pnorm", mean=mean(x), sd=sd(x)).


# TASK 3: LOG TRANSFORM
# 3a. Create log_height in 'clean_stunts' using log10(height_m).


# TASK 4: ONE-SAMPLE T-TEST
# 4a. Run a one-sample t-test on yale_students$hours_studied with mu = 20.

# 4b. Run a one-sample t-test on clean_stunts$height_m with mu = 10.


# TASK 5: PAIRED T-TEST
# 5a. Compare 'Cream_A' and 'Cream_B' from 'creams' dataset. Use paired = TRUE.


# TASK 6: UNPAIRED T-TEST
# 6a. Compare 'horn_length' by 'survival' using the 'lizards' data.
# Remember to use the formula syntax: Numeric ~ Group.


# TASK 7: POWER ANALYSIS
# 7a. Calculate power.t.test with delta = 10, sd = 15, power = 0.8, type = "two.sample".

# 7b. Calculate power.t.test with delta = 5, sd = 10, power = 0.9, type = "one.sample".

