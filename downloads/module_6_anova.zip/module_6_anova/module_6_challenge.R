# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 6 CHALLENGE
# 🍽️ THEME: FRIDAY NIGHT DINNER (ANOVA)
# ------------------------------------------------------------------------------

library(tidyverse)
dinner_ratings <- read.csv("dinner_ratings.csv")
maids <- read.csv("maids.csv")

# TASK 1: ANOVA
# 1a. Run an ANOVA (aov) to see if 'rating' depends on 'course' in 'dinner_ratings'.
# Save it as 'anova_result'.
# Use formula: rating ~ course

# 1b. Use summary() on 'anova_result' to see the p-value.


# TASK 2: TUKEY'S HSD
# 2a. Run TukeyHSD() on your 'anova_result' to see which courses differ.


# TASK 3: MORE ANOVA
# 3a. Run an ANOVA (aov) to see if 'tenure_days' depends on 'name' in 'maids'.
# Save as 'maids_aov' and summarize it.

