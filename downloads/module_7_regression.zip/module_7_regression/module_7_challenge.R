# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 7 CHALLENGE
# 📈 THEME: RICHARD'S INVESTMENTS (REGRESSION)
# ------------------------------------------------------------------------------

library(tidyverse)
investments <- read.csv("investments.csv")
market_data <- read.csv("market_data.csv")

# TASK 1: CORRELATION
# 1a. Run cor.test() to check the correlation between 'risk' and 'roi' in 'investments'.


# TASK 2: LINEAR REGRESSION
# 2a. Build a linear model (lm) predicting 'roi' from 'risk' in 'investments'.
# Save it as 'model'. Formula: roi ~ risk.

# 2b. Use summary() on 'model' to get the R-squared and coefficients.


# TASK 3: TIME SERIES REGRESSION
# 3a. Build a linear model predicting 'index' from 'day' using 'market_data'.
# Save as 'market_model' and summarize it.

