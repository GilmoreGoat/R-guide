# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: MODULE 8 CHALLENGE
# 💃 THEME: MISS PATTY'S STUDIO (CATEGORICAL)
# ------------------------------------------------------------------------------

library(tidyverse)
dancers <- read.csv("dancers.csv")

# TASK 1: TABLE
# 1a. Create a contingency table of 'age_group' and 'style' using table().
# Save it as 'dance_table'.


# TASK 2: CHI-SQUARED TEST
# 2a. Run chisq.test() on your 'dance_table' to see if age group and style are associated.


# TASK 3: ANOTHER TEST
# 3a. Test if there's an equal number of dancers in each 'age_group'.
# Use chisq.test(table(dancers$age_group)).

