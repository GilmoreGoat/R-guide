# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL A CHALLENGE
# 🦍 THEME: LIFE & DEATH BRIGADE (JOINING)
# ------------------------------------------------------------------------------

library(tidyverse)
guests <- read.csv("guests.csv")
society_list <- read.csv("society_list.csv")

# TASK 1: LEFT JOIN
# 1a. Left join 'guests' with 'society_list' by 'id'. Assign to 'party_roster'.


# TASK 2: INNER JOIN
# 2a. Inner join 'guests' with 'society_list'.


# TASK 3: CASE WHEN
# 3a. Mutate 'guests' to add a 'VIP_status' column using case_when().
# If status == "Member", then "VIP".
# If status == "Gatecrasher", then "Bouncer Alert".
# TRUE ~ "Regular"

