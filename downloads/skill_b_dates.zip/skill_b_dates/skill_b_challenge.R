# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL B CHALLENGE
# 📆 THEME: TOWN FESTIVALS (DATES)
# ------------------------------------------------------------------------------

library(tidyverse)
library(lubridate)
festivals <- read.csv("festivals.csv")
marathon <- read.csv("marathon.csv")

# TASK 1: PARSING DATES
# 1a. Mutate 'festivals' to convert 'date_str' (e.g., "Feb 14, 2024") to a date using mdy().
# Assign to a new column 'real_date'.


# TASK 2: DURATION
# 2a. Mutate 'marathon' to calculate 'duration' (end - start).


# TASK 3: EXTRACTING COMPONENTS
# 3a. Extract the month() from your 'real_date' column in 'festivals'.

