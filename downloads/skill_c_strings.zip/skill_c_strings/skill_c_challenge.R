# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL C CHALLENGE
# 🗞️ THEME: STARS HOLLOW GAZETTE (STRINGS)
# ------------------------------------------------------------------------------

library(tidyverse)
library(stringr)
gazette <- read.csv("gazette.csv")
rumors <- read.csv("rumors.csv")

# TASK 1: STRING DETECT
# 1a. Filter 'rumors' to keep rows where 'text' contains the word "wedding" (str_detect).


# TASK 2: STRING REPLACE
# 2a. Mutate 'rumors' to replace "cat" with "tiger" using str_replace().


# TASK 3: STRING LENGTH
# 3a. Mutate 'gazette' to add a column 'name_length' using str_length() on the 'writer' column.


# TASK 4: TO UPPER / TO LOWER
# 4a. Mutate 'gazette' to make the 'writer' names ALL CAPS using str_to_upper().

