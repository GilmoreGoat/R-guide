# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL D CHALLENGE
# 🛋️ THEME: MRS. KIM'S ANTIQUES (FUNCTIONAL PROGRAMMING)
# ------------------------------------------------------------------------------

library(tidyverse)
library(purrr)
antiques <- read.csv("antiques.csv")

# TASK 1: MAP
# 1a. Use map() on the 'price' column of 'antiques' to apply the sqrt() function.


# TASK 2: MAP_DBL
# 2a. Use map_dbl() on the 'price' column of 'antiques' to apply the sqrt() function (returns a vector).


# TASK 3: ANONYMOUS FUNCTIONS
# 3a. Use map_dbl() on the 'price' column to multiply each price by 1.10 (add 10% tax).
# Hint: map_dbl(antiques$price, ~ .x * 1.10)

