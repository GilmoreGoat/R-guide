# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL E CHALLENGE
# 🎸 THEME: THE DAR & HEP ALIEN (OOP)
# ------------------------------------------------------------------------------

# TASK 1: S3 CLASSES
# 1a. Create a list called 'band_member' with name = "Lane" and instrument = "Drums".
# 1b. Assign the class "rockstar" to 'band_member'.
# 1b. Write a generic method `play` and a specific method `play.rockstar` that prints "Rock on!".


# TASK 2: R6 CLASSES (Bonus)
# 2a. (Optional) Define an R6 class "Band" with a public method "gig".

