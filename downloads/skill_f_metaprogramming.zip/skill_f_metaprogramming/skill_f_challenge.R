# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL F CHALLENGE
# 🎶 THEME: THE TROUBADOUR (METAPROGRAMMING)
# ------------------------------------------------------------------------------

library(rlang)
library(tidyverse)

# TASK 1: QUOTATION
# 1a. Write a function `my_summarise` that takes a dataframe and a grouping variable.
# Use enquo() and !! to group the dataframe before summarising.

# Example:
# my_summarise <- function(df, group_var) {
#   var <- enquo(group_var)
#   df |> group_by(!!var) |> summarise(count = n())
# }

