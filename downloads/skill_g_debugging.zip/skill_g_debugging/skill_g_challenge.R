# ------------------------------------------------------------------------------
# 🏆 THE R GILMORE STUDY GUIDE: SKILL G CHALLENGE
# 🛡️ THEME: PARIS GELLER'S BUNKER (DEBUGGING)
# ------------------------------------------------------------------------------

# TASK 1: BROWSER()
# 1a. Write a loop from 1 to 5. Insert browser() inside the loop when i == 3.

# TASK 2: TRACEBACK
# 2a. Call a function that produces an error. Then mentally run traceback() (or actually run it in your console).

